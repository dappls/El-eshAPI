package net.dappls.eleshapi.Testing;

import net.dappls.eleshapi.events.PreventEatingEvent;
import net.fabricmc.fabric.api.util.TriState;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class noEatingItem extends Item {

    public noEatingItem(Settings settings) {
        super(settings);
        PreventEatingEvent.EVENT.register(player -> {
            ItemStack mainHandStack = player.getMainHandStack();
            ItemStack offHandStack = player.getOffHandStack();
            if(mainHandStack.isOf(this.asItem()) || offHandStack.isOf(this.asItem())) {
                return TriState.TRUE;
            }
            return TriState.DEFAULT;
        });
    }
}
