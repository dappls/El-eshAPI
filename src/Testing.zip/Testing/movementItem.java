package net.dappls.eleshapi.Testing;

import net.dappls.eleshapi.events.ModifyMovementEvents;
import net.dappls.eleshapi.events.PreventRidingEvent;
import net.fabricmc.fabric.api.util.TriState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;
import org.jspecify.annotations.Nullable;

public class movementItem extends Item {
    public movementItem(Settings settings) {
        super(settings);

    }

    @Override
    public void inventoryTick(ItemStack stack, ServerWorld world, Entity entity, @Nullable EquipmentSlot slot) {
        PreventRidingEvent.EVENT.register(entity1 -> {
            if(entity1 instanceof LivingEntity) {
                ItemStack mainHandStack = ((LivingEntity) entity1).getMainHandStack();
                if (mainHandStack.isOf(this.asItem())) {
                    return TriState.TRUE;
                }
            }
            return TriState.DEFAULT;
        });
        ModifyMovementEvents.MOVEMENT_VELOCITY.register((velocity, entity1) -> {
                ItemStack mainHandStack = entity1.getMainHandStack();
                if (mainHandStack.isOf(this.asItem())) {
                    entity1.setSprinting(false);
                    return new Vec3d(0, 0, 0);
                } else {
                    return velocity;
                }

        });
        ModifyMovementEvents.JUMP_VELOCITY.register((velocity, entity2) -> {
            ItemStack mainHandStack = entity2.getMainHandStack();
            if (mainHandStack.isOf(this.asItem())) {
                entity2.setSprinting(false);
                return new Vec3d(0, 0, 0);
            } else {
                return velocity;
            }
        });

       }
}
