package net.dappls.eleshapi.Testing;

import net.dappls.eleshapi.client.clientevents.ReplaceHeartTexturesEvent;
import net.minecraft.util.Identifier;

public class TestClientRegistries {

    private static final String MOD_ID = "eleshapi";

    public static void bootstrap() {
        registerTestHeartTextures();
    }

    private static void registerTestHeartTextures() {
        ReplaceHeartTexturesEvent.EVENT.register(player -> {
            // Example: Replace hearts when player is on fire
            if (player.isOnFire()) {
                return new ReplaceHeartTexturesEvent.TextureSet(
                    Identifier.of(MOD_ID, "hearts/fire_full"),
                    Identifier.of(MOD_ID, "hearts/fire_full_blinking"),
                    Identifier.of(MOD_ID, "hearts/fire_half"),
                    Identifier.of(MOD_ID, "hearts/fire_half_blinking"),
                    Identifier.of(MOD_ID, "hearts/fire_hardcore_full"),
                    Identifier.of(MOD_ID, "hearts/fire_hardcore_full_blinking"),
                    Identifier.of(MOD_ID, "hearts/fire_hardcore_half"),
                    Identifier.of(MOD_ID, "hearts/fire_hardcore_half_blinking")
                );
            }

            return null;
        });
    }
}
